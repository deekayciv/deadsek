     |     '       /  |
     /__      ___ (  /
     \\--`-'-|`---\\ |
      |' _/   ` __/ /
      '._  W    ,--'
         |_:_._/


     www.deadsek.net

     CivMC Informational Website